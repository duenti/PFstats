#!/bin/sh
 export LD_LIBRARY_PATH=`pwd`/libs
 _PLATFORM_PLUGIN_PATH=`pwd`/libs/platforms
 ./Pfstats