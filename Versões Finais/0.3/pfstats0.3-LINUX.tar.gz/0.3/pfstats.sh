#!/bin/sh
export LD_LIBRARY_PATH=`pwd`/lib
export QT_QPA_PLATFORM_PLUGIN_PATH=`pwd`/lib
./Pfstats
